window.ipcRenderer = require('electron').ipcRenderer;
console.log('ipcRenderer', window.ipcRenderer);